# Caddy Vault — Installation Guide

## 🚀 Quick Install (2 minutes)

### Step 1: Download the Extension Files
Download the latest release from [GitHub Releases](https://github.com/your-org/caddyvault/releases) or clone this repository.

### Step 2: Generate Icons (One-Time)
1. Open `generate_icons.html` in Chrome
2. Click **Download All Icons**
3. Move the 3 PNG files to the `icons/` folder in this directory

### Step 3: Load Into Chrome
1. Open `chrome://extensions/`
2. Toggle **Developer mode** (top-right corner)
3. Click **Load unpacked**
4. Select the `caddyvault/` folder
5. Done! The CV icon appears in your toolbar

---

## ⚙️ Optional: Google Calendar Integration

To schedule study sessions from your calendar:

### Create Google Cloud Project
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project
3. Search for **Google Calendar API** → Enable it

### Create OAuth Credentials
1. Go to **APIs & Services → Credentials**
2. Click **Create Credentials → OAuth client ID**
3. Choose **Chrome Extension**
4. Copy your extension ID from `chrome://extensions/`
5. Paste the extension ID, click **Create**
6. Copy the **Client ID**

### Add Client ID to Extension
1. Open `manifest.json`
2. Replace `"YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com"` with your Client ID
3. Reload the extension in `chrome://extensions/`

### Connect in Extension
1. Click the **CV** icon
2. Click **Connect Google Calendar**
3. Approve the consent screen
4. Your calendar events now appear in the Schedule tab

---

## 💾 What Gets Stored?

- **All data stays local** — stored in your browser's `chrome.storage.local`
- No servers, no accounts, no data leaves your computer
- If you uninstall, all data is permanently deleted

---

## 🔧 Troubleshooting

### Icons not showing?
- Make sure the 3 PNG files are in the `icons/` folder
- Icons must be named exactly: `icon16.png`, `icon48.png`, `icon128.png`

### Extension won't load?
- Check that Developer mode is ON
- Make sure you selected the `caddyvault/` folder (not the parent folder)

### Calendar integration not working?
- Verify the Client ID in `manifest.json` matches your Google Cloud project
- Check that Google Calendar API is enabled in your Google Cloud Console

---

## 📦 File Structure

```
caddyvault/
├── manifest.json              Extension configuration
├── background.js              Service worker (tab tracking, notifications)
├── popup.html                 Extension popup UI
├── popup.css                  Popup styles
├── popup.js                   Popup logic
├── calendar.js                Google Calendar API
├── generate_icons.html        Icon generator (open once in browser)
├── icons/
│   ├── icon16.png            Generated from generate_icons.html
│   ├── icon48.png
│   └── icon128.png
└── INSTALL.md                This file
```

---

## ✨ How It Works

| Action | How |
|--------|-----|
| **Archive** | Inactive tabs automatically move to your vault after 24 hours |
| **Group** | Tabs are automatically categorized by topic (Uni, Research, Code, etc.) |
| **Search** | Find any archived tab with keyword search |
| **Restore** | Click a group or tab to restore it, or connect Google Calendar for auto-restore |
| **Notify** | Get a notification before your scheduled study session with one-click restore |

---

## 📞 Support

- Issues? Open a GitHub issue
- Questions? Check the [FAQ](#)
- Want to contribute? See [CONTRIBUTING.md](#)
