# Caddy Vault — Your Automated Workflow Caddy

A Chrome extension that archives inactive tabs, groups them intelligently, and restores them exactly when you need them — integrated with your Google Calendar.

**Free • No account • Private • Open source**

---

## 🎯 What It Does

### Archive
Tabs inactive for 24 hours automatically move to your vault, keeping your browser clean.

### Group
Archived tabs are automatically categorized by topic (Uni, Research, Code, YouTube, Social, etc.) — one-click restore for entire sessions.

### Restore
Find any tab with keyword search, or connect your Google Calendar for automatic reminders before your study sessions.

### Notify
Get a notification before your scheduled time with matching tabs ready to restore in one click.

---

## 🚀 Quick Start

### 1. Download
```bash
git clone https://github.com/your-username/caddyvault.git
cd caddyvault
```

### 2. Setup (Mac/Linux)
```bash
bash setup.sh
```

### 2. Setup (Windows)
```cmd
setup.bat
```

### 3. Load into Chrome
1. Open `chrome://extensions/`
2. Toggle **Developer mode** (top-right)
3. Click **Load unpacked**
4. Select the `caddyvault/` folder

✨ **Done!** The CV icon appears in your toolbar.

---

## 📖 Full Documentation

- **[INSTALL.md](./INSTALL.md)** — Detailed setup guide
- **[SETUP.md](./SETUP.md)** — Quick reference
- **[website/download.html](./website/download.html)** — Download instructions

---

## ⚙️ Optional: Google Calendar Integration

To schedule study sessions from your calendar:

1. Create a Google Cloud Project at [console.cloud.google.com](https://console.cloud.google.com)
2. Enable the **Google Calendar API**
3. Create OAuth credentials for Chrome Extension
4. Copy your extension ID from `chrome://extensions/`
5. Use that ID to create the OAuth credentials
6. Copy the **Client ID** and paste it into `manifest.json`
7. Reload the extension
8. Click the CV icon → **Connect Google Calendar**

See [INSTALL.md](./INSTALL.md) for detailed instructions.

---

## 📦 File Structure

```
caddyvault/
├── manifest.json              Extension configuration (MV3)
├── background.js              Service worker (tab tracking, notifications)
├── popup.html                 Extension popup UI
├── popup.css                  Popup styles (dark theme + gold accents)
├── popup.js                   Popup logic (groups, search, restore)
├── calendar.js                Google Calendar API helpers
├── create_icons.py            Icon generator (no dependencies)
├── generate_icons.html        Browser-based icon generator
├── setup.sh                   Setup script for Mac/Linux
├── setup.bat                  Setup script for Windows
├── icons/
│   ├── icon16.png            Extension icon (16×16)
│   ├── icon48.png            Extension icon (48×48)
│   └── icon128.png           Extension icon (128×128)
├── website/
│   ├── index.html            Marketing website
│   ├── download.html         Download/install guide
│   ├── styles.css            Website styles
│   └── script.js             Website demo & animations
├── INSTALL.md                Installation guide (detailed)
├── SETUP.md                  Quick setup reference
└── README.md                 This file
```

---

## 💾 How Data Is Stored

- **All data stays local** — stored in your browser's `chrome.storage.local`
- **No servers** — everything runs on your computer
- **No accounts** — no login required
- **No tracking** — your activity is private
- **Survives restarts** — study reminders persist across sessions
- **Delete anytime** — uninstalling removes all data permanently

---

## 🎨 Design

Built with:
- **Font:** EB Garamond (serif)
- **Theme:** Dark mode with gold accents
- **Colors:**
  - Background: `#09080F`
  - Gold: `#C39E37`
  - Cream text: `#EDE8D5`
- **Architecture:** MV3 Chrome extension (modern standard)

---

## 🔧 Development

### Requirements
- Python 3.6+ (for icon generation)
- Chrome browser (v88+)
- Text editor or IDE

### Building Icons
```bash
python3 create_icons.py
```

Or open `generate_icons.html` in Chrome and download manually.

### Loading for Development
1. Make your changes
2. Open `chrome://extensions/`
3. Click the **reload** icon on the CaddyVault card
4. Test in the popup

---

## 📋 Features

| Feature | Status |
|---------|--------|
| Archive inactive tabs | ✅ Automatic |
| Smart grouping | ✅ Automatic |
| Keyword search | ✅ Full text search |
| One-click restore | ✅ Groups or individual |
| Google Calendar sync | ✅ Optional integration |
| Study reminders | ✅ Chrome notifications |
| Private/local storage | ✅ No accounts |
| Dark mode UI | ✅ Built-in |
| Keyboard shortcuts | 🔄 Coming soon |
| Customizable archive time | 🔄 Coming soon |
| Export/backup | 🔄 Coming soon |

---

## 🐛 Known Limitations

- Only works in Chrome/Edge (Chromium-based)
- 24-hour archive threshold is fixed (customization coming soon)
- No sync across devices (local-only storage)
- Doesn't track `chrome://`, `about:`, or internal pages

---

## 🤝 Contributing

We welcome contributions! Please:

1. Fork this repository
2. Create a feature branch (`git checkout -b feature/amazing-thing`)
3. Make your changes
4. Test in Chrome
5. Submit a pull request

### Code Style
- Use vanilla JavaScript (no frameworks for popup)
- No external dependencies
- Clear variable names
- Comments for complex logic

---

## 📄 License

MIT License — feel free to use, modify, and share.

---

## 🙋 Support

- **Issues?** Open a [GitHub Issue](https://github.com/your-username/caddyvault/issues)
- **Questions?** Check the [FAQ](#) or [INSTALL.md](./INSTALL.md)
- **Want to chat?** Start a [GitHub Discussion](https://github.com/your-username/caddyvault/discussions)

---

## 🎉 Built By

**Ronik Khanna** — [@ronikhanna](https://twitter.com/ronikhanna)

Inspired by the endless struggle of managing research, study materials, and side projects across too many tabs.

---

**Stop losing your research. CaddyVault remembers it for you.**
