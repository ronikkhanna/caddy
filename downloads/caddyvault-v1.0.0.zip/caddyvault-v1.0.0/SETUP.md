# CaddyVault — Quick Setup

## 🚀 Fastest Way (60 seconds)

### Mac/Linux:
```bash
bash setup.sh
```

### Windows:
```cmd
setup.bat
```

This generates icons and shows you the next 2 steps.

---

## ⚙️ Manual Setup (if you prefer)

1. **Generate icons:**
   - Run: `python3 create_icons.py` (Mac/Linux) or `python create_icons.py` (Windows)
   - Or open `generate_icons.html` in Chrome and download icons manually

2. **Load into Chrome:**
   - Open `chrome://extensions/`
   - Toggle **Developer mode** (top-right)
   - Click **Load unpacked**
   - Select the `caddyvault` folder

3. **Done!** 🎉
   - The CV icon appears in your toolbar

---

## 📖 Full Documentation

See **INSTALL.md** for:
- Detailed setup instructions
- Google Calendar integration guide
- Troubleshooting
- File structure

---

## 💡 How It Works

- **Archive**: Inactive tabs move to your vault automatically
- **Group**: Tabs are categorized by topic (Uni, Research, Code, etc.)
- **Restore**: Find and restore tabs with one click
- **Calendar**: Connect Google Calendar for scheduled study sessions
- **Notify**: Get reminders before your study time with one-click restore

---

## ✨ Key Features

- ✅ **Zero accounts** — no login required
- ✅ **Private** — all data stays in your browser
- ✅ **Free** — open source, always free
- ✅ **Fast** — instant search and restore
- ✅ **Smart** — automatic tab categorization

All data is stored locally in `chrome.storage.local` — nothing leaves your browser.
