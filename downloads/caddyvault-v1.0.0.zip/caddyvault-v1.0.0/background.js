// Caddy — Background Service Worker
// Core loop: detect inactive tabs → archive → close → surface on demand / calendar trigger

const ARCHIVE_THRESHOLD_MS = 24 * 60 * 60 * 1000; // 24 hours
const REMINDER_LEAD_MS     = 3 * 60 * 1000;        // fire 3 min before event
const MAX_ARCHIVE_SIZE     = 500;
const INTERNAL_URL_PREFIXES = ['chrome://', 'chrome-extension://', 'about:', 'edge://', 'moz-extension://'];

// ── Tab registry (manual-close detection) ─────────────────────────────────────

const tabRegistry = new Map(); // tabId → { url, title, favIconUrl, openedAt }

// Seed registry from tabs already open when the service worker wakes
chrome.tabs.query({}).then(tabs => {
  for (const tab of tabs) {
    if (tab.url && !INTERNAL_URL_PREFIXES.some(p => tab.url.startsWith(p))) {
      tabRegistry.set(tab.id, {
        url:       tab.url,
        title:     tab.title || tab.url,
        favIconUrl: tab.favIconUrl || '',
        openedAt:  tab.lastAccessed || Date.now()
      });
    }
  }
});

chrome.tabs.onCreated.addListener(tab => {
  if (tab.url && !INTERNAL_URL_PREFIXES.some(p => tab.url.startsWith(p))) {
    tabRegistry.set(tab.id, {
      url:       tab.url,
      title:     tab.title || tab.url,
      favIconUrl: tab.favIconUrl || '',
      openedAt:  Date.now()
    });
  }
});

chrome.tabs.onUpdated.addListener((tabId, _info, tab) => {
  if (!tab.url || INTERNAL_URL_PREFIXES.some(p => tab.url.startsWith(p))) return;
  const prev = tabRegistry.get(tabId);
  tabRegistry.set(tabId, {
    url:       tab.url,
    title:     tab.title || tab.url,
    favIconUrl: tab.favIconUrl || '',
    openedAt:  prev?.openedAt ?? Date.now()
  });
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const info = tabRegistry.get(tabId);
  tabRegistry.delete(tabId);

  if (!info?.url) return;
  if (INTERNAL_URL_PREFIXES.some(p => info.url.startsWith(p))) return;
  if (Date.now() - info.openedAt < 10_000) return; // skip accidental/redirect closes

  const { archivedTabs } = await chrome.storage.local.get('archivedTabs');
  const archive = archivedTabs || [];

  if (archive.some(t => t.url === info.url)) return; // already in vault

  const now   = Date.now();
  const entry = {
    id:            `t_${now}_${Math.random().toString(36).slice(2, 6)}`,
    url:           info.url,
    title:         info.title,
    favIconUrl:    info.favIconUrl,
    archivedAt:    now,
    lastActiveAt:  now,
    domain:        extractDomain(info.url),
    keywords:      buildKeywords({ url: info.url, title: info.title }),
    closedManually: true
  };

  await chrome.storage.local.set({
    archivedTabs: [entry, ...archive].slice(0, MAX_ARCHIVE_SIZE)
  });
});

// ── Init ─────────────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    await chrome.storage.local.set({
      archivedTabs:  [],
      reminders:     [],
      calConnected:  false
    });
  }
  scheduleAlarms();
});

chrome.runtime.onStartup.addListener(scheduleAlarms);

function scheduleAlarms() {
  chrome.alarms.create('archive-check',   { periodInMinutes: 60 });
  chrome.alarms.create('calendar-sync',   { periodInMinutes: 30 });
}

// ── Alarm dispatch ────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'archive-check') return archiveInactiveTabs();
  if (alarm.name === 'calendar-sync') return syncCalendarReminders();
  if (alarm.name.startsWith('reminder_')) return fireReminder(alarm.name.slice(9));
});

// ── Tab auto-archive ──────────────────────────────────────────────────────────

async function archiveInactiveTabs(thresholdMs = ARCHIVE_THRESHOLD_MS) {
  const now  = Date.now();
  const tabs = await chrome.tabs.query({});

  const candidates = tabs.filter(tab =>
    tab.url &&
    !INTERNAL_URL_PREFIXES.some(p => tab.url.startsWith(p)) &&
    tab.lastAccessed != null &&
    (now - tab.lastAccessed) > thresholdMs
  );

  if (!candidates.length) return 0;

  const { archivedTabs } = await chrome.storage.local.get('archivedTabs');
  const archive  = archivedTabs || [];
  const existing = new Set(archive.map(a => a.url));

  const newEntries = [];
  const tabIdsToClose = [];
  const batchId = `batch_${now}`;

  for (const tab of candidates) {
    if (existing.has(tab.url)) continue;

    newEntries.push({
      id:           `t_${now}_${Math.random().toString(36).slice(2, 6)}`,
      url:          tab.url,
      title:        tab.title || tab.url,
      favIconUrl:   tab.favIconUrl || '',
      archivedAt:   now,
      lastActiveAt: tab.lastAccessed,
      domain:       extractDomain(tab.url),
      keywords:     buildKeywords(tab),
      batchId
    });

    tabIdsToClose.push(tab.id);
  }

  if (!newEntries.length) return 0;

  // Merge and deduplicate by URL (new entries win, keeping order)
  const merged  = [...newEntries, ...archive];
  const seenUrls = new Set();
  const updated  = merged.filter(t => {
    if (seenUrls.has(t.url)) return false;
    seenUrls.add(t.url);
    return true;
  }).slice(0, MAX_ARCHIVE_SIZE);
  await chrome.storage.local.set({ archivedTabs: updated });

  for (const id of tabIdsToClose) {
    try { await chrome.tabs.remove(id); } catch { /* tab may already be closed */ }
  }

  return newEntries.length;
}

// ── Calendar sync & smart reminders ──────────────────────────────────────────

async function syncCalendarReminders() {
  const { calConnected } = await chrome.storage.local.get('calConnected');
  if (!calConnected) return;

  const token = await getSilentToken();
  if (!token) return;

  try {
    const events  = await fetchCalendarEvents(token);
    const { archivedTabs, reminders } = await chrome.storage.local.get(['archivedTabs', 'reminders']);
    const archive  = archivedTabs || [];
    const existing = new Set((reminders || []).map(r => r.eventId));

    const newReminders = [];

    for (const event of events) {
      if (existing.has(event.id)) continue;

      const startTime = event.start?.dateTime || event.start?.date;
      if (!startTime) continue;

      const startMs  = new Date(startTime).getTime();
      const fireAtMs = startMs - REMINDER_LEAD_MS; // 3 min before

      if (fireAtMs <= Date.now()) continue; // already passed

      const eventKeywords = extractKeywords(event.summary || '');
      const matchedTabs   = findMatchingTabs(archive, eventKeywords);
      // Create reminder even if no tabs matched — still useful as a heads-up

      const reminder = {
        id:          `r_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        eventId:     event.id,
        eventTitle:  event.summary || 'Event',
        startTime:   startMs,
        fireAt:      fireAtMs,
        tabIds:      matchedTabs.map(t => t.id),
        fired:       false
      };

      newReminders.push(reminder);
      // Schedule alarm 3 minutes before the event
      chrome.alarms.create(`reminder_${reminder.id}`, { when: fireAtMs });
    }

    if (newReminders.length) {
      const all = [...(reminders || []), ...newReminders];
      await chrome.storage.local.set({ reminders: all });
    }
  } catch (err) {
    console.warn('Caddy calendar sync failed:', err.message);
  }
}

async function fireReminder(reminderId) {
  const { reminders, archivedTabs } = await chrome.storage.local.get(['reminders', 'archivedTabs']);
  const reminder = (reminders || []).find(r => r.id === reminderId);
  if (!reminder || reminder.fired) return;

  const archive = archivedTabs || [];
  const tabs    = reminder.tabIds.map(id => archive.find(t => t.id === id)).filter(Boolean);

  await chrome.notifications.create(`reminder_${reminderId}`, {
    type:             'basic',
    iconUrl:          'icons/icon48.png',
    title:            `Caddy Vault — ${reminder.eventTitle} in 3 min`,
    message:          tabs.length > 0
      ? `${tabs.length} tab${tabs.length !== 1 ? 's' : ''} ready to restore for this session.`
      : `Your session "${reminder.eventTitle}" starts in 3 minutes.`,
    buttons:          tabs.length > 0 ? [{ title: 'Restore Tabs' }] : [],
    requireInteraction: true
  });

  const updated = reminders.map(r => r.id === reminderId ? { ...r, fired: true } : r);
  await chrome.storage.local.set({ reminders: updated });
}

// ── Notification interaction ──────────────────────────────────────────────────

chrome.notifications.onButtonClicked.addListener(async (notifId, btnIdx) => {
  if (!notifId.startsWith('reminder_') || btnIdx !== 0) return;

  const reminderId = notifId.slice(9);
  const { reminders, archivedTabs } = await chrome.storage.local.get(['reminders', 'archivedTabs']);
  const reminder = (reminders || []).find(r => r.id === reminderId);
  if (!reminder) return;

  const archive = archivedTabs || [];
  const tabs    = reminder.tabIds.map(id => archive.find(t => t.id === id)).filter(Boolean);

  for (let i = 0; i < tabs.length; i++) {
    await chrome.tabs.create({ url: tabs[i].url, active: i === 0 });
  }

  chrome.notifications.clear(notifId);
});

chrome.notifications.onClicked.addListener((notifId) => {
  chrome.notifications.clear(notifId);
});

// ── Message handler (from popup) ──────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  dispatch(msg).then(reply).catch(err => reply({ ok: false, error: err.message }));
  return true;
});

async function dispatch(msg) {
  switch (msg.type) {

    case 'GET_STATE': {
      const data = await chrome.storage.local.get(['archivedTabs', 'reminders', 'calConnected']);
      return { ok: true, ...data };
    }

    case 'RESTORE_TAB': {
      const { archivedTabs } = await chrome.storage.local.get('archivedTabs');
      const tab = (archivedTabs || []).find(t => t.id === msg.id);
      if (!tab) return { ok: false, error: 'Tab not found in archive' };
      await chrome.tabs.create({ url: tab.url, active: true });
      return { ok: true };
    }

    case 'RESTORE_MANY': {
      const { archivedTabs } = await chrome.storage.local.get('archivedTabs');
      const archive = archivedTabs || [];
      for (let i = 0; i < msg.ids.length; i++) {
        const tab = archive.find(t => t.id === msg.ids[i]);
        if (tab) await chrome.tabs.create({ url: tab.url, active: i === 0 });
      }
      return { ok: true };
    }

    case 'DELETE_TAB': {
      const { archivedTabs } = await chrome.storage.local.get('archivedTabs');
      const updated = (archivedTabs || []).filter(t => t.id !== msg.id);
      await chrome.storage.local.set({ archivedTabs: updated });
      return { ok: true };
    }

    case 'ARCHIVE_NOW': {
      // Use 1 minute threshold so any tab opened >1min ago gets archived
      const count = await archiveInactiveTabs(60 * 1000);
      return { ok: true, count };
    }

    case 'SET_CAL_CONNECTED': {
      await chrome.storage.local.set({ calConnected: msg.value });
      if (msg.value) await syncCalendarReminders();
      return { ok: true };
    }

    case 'SYNC_CALENDAR': {
      await syncCalendarReminders();
      return { ok: true };
    }

    case 'RESYNC_CALENDAR': {
      // Clear existing unfired reminders and re-sync from scratch
      const { reminders } = await chrome.storage.local.get('reminders');
      const fired = (reminders || []).filter(r => r.fired);
      await chrome.storage.local.set({ reminders: fired });
      await syncCalendarReminders();
      return { ok: true };
    }

    case 'DEBUG_CALENDAR': {
      const out = { ok: true, tokenOk: false, events: [], alarms: [], reminders: [] };

      // 1. Token check
      const token = await getSilentToken();
      out.tokenOk = !!token;
      if (!token) {
        out.error = 'No auth token — disconnect and reconnect calendar';
        return out;
      }

      // 2. Calendar events
      try {
        const events = await fetchCalendarEvents(token);
        const now = Date.now();
        out.events = events.map(e => {
          const startMs  = new Date(e.start?.dateTime || e.start?.date).getTime();
          const fireAtMs = startMs - REMINDER_LEAD_MS;
          return {
            title: e.summary,
            alreadyPast: fireAtMs <= now,
            minsUntilFire: Math.round((fireAtMs - now) / 60000)
          };
        });
      } catch (e) {
        out.calError = e.message;
      }

      // 3. Scheduled alarms
      const alarms = await chrome.alarms.getAll();
      out.alarms = alarms.map(a => a.name);

      // 4. Stored reminders
      const { reminders } = await chrome.storage.local.get('reminders');
      out.reminders = (reminders || []).map(r => ({
        event: r.eventTitle,
        fired: r.fired,
        minsUntilFire: Math.round((r.fireAt - Date.now()) / 60000)
      }));

      return out;
    }

    case 'TEST_NOTIFICATION': {
      await chrome.notifications.create(`test_notif_${Date.now()}`, {
        type:    'basic',
        iconUrl: 'icons/icon48.png',
        title:   'Caddy Vault — Test',
        message: 'Notifications are working! ✓',
        requireInteraction: false
      });
      return { ok: true };
    }

    case 'FIRE_NOW': {
      // Force-fire a fake reminder right now, bypassing the alarm
      await chrome.notifications.create(`force_notif_${Date.now()}`, {
        type:    'basic',
        iconUrl: 'icons/icon48.png',
        title:   `Caddy Vault — ${msg.eventTitle || 'Test Event'} · now`,
        message: 'Your session is starting. Caddy Vault is watching.',
        requireInteraction: true
      });
      return { ok: true };
    }

    default:
      return { ok: false, error: `Unknown: ${msg.type}` };
  }
}

// ── Utilities ─────────────────────────────────────────────────────────────────

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

// Smart domain aliases — so searching "gmail" finds mail.google.com, etc.
const DOMAIN_ALIASES = {
  'mail.google.com':     ['gmail', 'google', 'mail', 'inbox', 'email'],
  'docs.google.com':     ['google', 'docs', 'document', 'gdocs'],
  'drive.google.com':    ['google', 'drive', 'gdrive', 'files'],
  'calendar.google.com': ['google', 'calendar', 'gcal', 'schedule'],
  'sheets.google.com':   ['google', 'sheets', 'spreadsheet', 'excel'],
  'slides.google.com':   ['google', 'slides', 'presentation', 'deck'],
  'meet.google.com':     ['google', 'meet', 'meeting', 'video'],
  'youtube.com':         ['youtube', 'video', 'watch'],
  'reddit.com':          ['reddit', 'post', 'thread'],
  'twitter.com':         ['twitter', 'tweet', 'x'],
  'x.com':               ['twitter', 'tweet', 'x'],
  'linkedin.com':        ['linkedin', 'jobs', 'network'],
  'github.com':          ['github', 'code', 'repo', 'git'],
  'stackoverflow.com':   ['stackoverflow', 'stack', 'code', 'answer'],
  'notion.so':           ['notion', 'notes', 'wiki'],
  'figma.com':           ['figma', 'design', 'prototype'],
  'canvas.ubc.ca':       ['canvas', 'ubc', 'course', 'assignment'],
  'chat.openai.com':     ['chatgpt', 'openai', 'gpt', 'ai'],
  'claude.ai':           ['claude', 'anthropic', 'ai'],
  'spotify.com':         ['spotify', 'music', 'playlist'],
  'netflix.com':         ['netflix', 'movie', 'show', 'watch'],
  'amazon.com':          ['amazon', 'shop', 'order'],
  'wikipedia.org':       ['wikipedia', 'wiki', 'encyclopedia'],
};

const STOP_WORDS = new Set([
  'the','a','an','is','in','it','of','to','and','for','on','with','at','by','from',
  'that','this','are','be','was','or','as','its','my','we','you','how','what','when',
  'where','why','who','do','not','com','www','http','https','org','net','edu','html'
]);

function extractKeywords(text) {
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w));
}

function buildKeywords(tab) {
  const domain   = extractDomain(tab.url);
  const base     = extractKeywords(`${tab.title} ${tab.url}`);
  const aliases  = DOMAIN_ALIASES[domain] || [];
  // Also check subdomain-stripped version
  const rootDomain = domain.split('.').slice(-2).join('.');
  const rootAliases = DOMAIN_ALIASES[rootDomain] || [];
  return [...new Set([...base, ...aliases, ...rootAliases])];
}

function findMatchingTabs(archive, eventKeywords) {
  if (!eventKeywords.length) return [];

  return archive
    .map(tab => {
      const hits = eventKeywords.filter(kw =>
        tab.keywords?.includes(kw) ||
        tab.title.toLowerCase().includes(kw) ||
        tab.domain.toLowerCase().includes(kw)
      ).length;
      return { ...tab, hits };
    })
    .filter(t => t.hits > 0)
    .sort((a, b) => b.hits - a.hits)
    .slice(0, 10);
}

function getSilentToken() {
  return new Promise(resolve => {
    chrome.identity.getAuthToken({ interactive: false }, token => {
      if (chrome.runtime.lastError || !token) resolve(null);
      else resolve(token);
    });
  });
}

async function fetchCalendarEvents(token) {
  const now    = new Date();
  const future = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const params = new URLSearchParams({
    timeMin:      now.toISOString(),
    timeMax:      future.toISOString(),
    singleEvents: 'true',
    orderBy:      'startTime',
    maxResults:   '30'
  });
  const res = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?${params}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw new Error(`Calendar API ${res.status}`);
  const data = await res.json();
  return data.items || [];
}
