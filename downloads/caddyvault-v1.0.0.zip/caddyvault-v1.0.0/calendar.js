// CaddyVault — Google Calendar helpers (popup context only)

const CALENDAR_BASE = 'https://www.googleapis.com/calendar/v3';

export function getAuthToken(interactive = true) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, token => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(token);
    });
  });
}

export async function fetchUpcomingEvents(token, daysAhead = 7) {
  const now    = new Date();
  const future = new Date(now.getTime() + daysAhead * 86400000);

  const params = new URLSearchParams({
    timeMin:      now.toISOString(),
    timeMax:      future.toISOString(),
    singleEvents: 'true',
    orderBy:      'startTime',
    maxResults:   '30'
  });

  const res = await fetch(`${CALENDAR_BASE}/calendars/primary/events?${params}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (res.status === 401) {
    await new Promise(r => chrome.identity.removeCachedAuthToken({ token }, r));
    throw new Error('401: session expired');
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `HTTP ${res.status}`);
  }

  const data = await res.json();
  return data.items || [];
}
