"""
CaddyVault — PNG icon generator (no third-party deps needed)
Run: python create_icons.py
"""
import struct
import zlib
import os

def make_png(size):
    """Create a size×size PNG with the CV monogram on a dark background."""
    # Palette: background #09080F, gold #C39E37, cream #EDE8D5
    BG   = (9,   8,  15)
    GOLD = (195, 158, 55)
    CREAM= (237, 232, 213)

    # Build pixel grid
    pixels = [[BG] * size for _ in range(size)]

    # Draw rounded-rect background (already bg, just add a subtle gold border)
    r = max(2, size // 7)
    for y in range(size):
        for x in range(size):
            # Gold border ring
            in_border = (
                (x < r and y < r and (x-r)**2 + (y-r)**2 > (r-1)**2) or
                (x >= size-r and y < r and (x-(size-r-1))**2 + (y-r)**2 > (r-1)**2) or
                (x < r and y >= size-r and (x-r)**2 + (y-(size-r-1))**2 > (r-1)**2) or
                (x >= size-r and y >= size-r and
                 (x-(size-r-1))**2 + (y-(size-r-1))**2 > (r-1)**2)
            )
            on_border = (
                x == 0 or x == size-1 or y == 0 or y == size-1
            )
            if on_border or in_border:
                pixels[y][x] = GOLD

    # Draw "CV" text using pixel art for each size
    draw_cv(pixels, size, CREAM, GOLD)

    # Encode as PNG
    raw = bytearray()
    for row in pixels:
        raw.append(0)  # filter type: None
        for (rr, gg, bb) in row:
            raw += bytes([rr, gg, bb])

    def make_chunk(tag, data):
        crc = zlib.crc32(tag + data) & 0xFFFFFFFF
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', crc)

    ihdr = struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)

    return (
        b'\x89PNG\r\n\x1a\n' +
        make_chunk(b'IHDR', ihdr) +
        make_chunk(b'IDAT', idat) +
        make_chunk(b'IEND', b'')
    )


def draw_cv(pixels, size, color, accent):
    """Stamp a tiny 'CV' into the pixel grid, scaled to size."""
    # Bitmap glyphs for C and V (5×7 grid each)
    C = [
        "011110",
        "100001",
        "100000",
        "100000",
        "100000",
        "100001",
        "011110",
    ]
    V = [
        "100001",
        "100001",
        "100001",
        "010010",
        "010010",
        "001100",
        "000000",
    ]

    glyph_h = len(C)
    glyph_w = len(C[0])
    gap = 1
    total_w = glyph_w * 2 + gap

    scale = max(1, size // 14)
    total_w_scaled = total_w * scale
    total_h_scaled = glyph_h * scale

    ox = (size - total_w_scaled) // 2
    oy = (size - total_h_scaled) // 2

    for row_i, row in enumerate(C):
        for col_i, bit in enumerate(row):
            if bit == '1':
                for sy in range(scale):
                    for sx in range(scale):
                        py = oy + row_i * scale + sy
                        px = ox + col_i * scale + sx
                        if 0 <= py < size and 0 <= px < size:
                            pixels[py][px] = color

    x_offset = (glyph_w + gap) * scale
    for row_i, row in enumerate(V):
        for col_i, bit in enumerate(row):
            if bit == '1':
                for sy in range(scale):
                    for sx in range(scale):
                        py = oy + row_i * scale + sy
                        px = ox + x_offset + col_i * scale + sx
                        if 0 <= py < size and 0 <= px < size:
                            pixels[py][px] = color


if __name__ == '__main__':
    os.makedirs('icons', exist_ok=True)
    for size in [16, 48, 128]:
        data = make_png(size)
        path = f'icons/icon{size}.png'
        with open(path, 'wb') as f:
            f.write(data)
        print(f'  OK  {path}  ({size}x{size}, {len(data)} bytes)')
    print('\nIcons ready. Load the extension in chrome://extensions/ -> Load unpacked.')
