import { getAuthToken } from './calendar.js';

// ── State ─────────────────────────────────────────────────────────────────────

let state = {
  archive:      [],
  reminders:    [],
  calConnected: false,
  query:        ''
};

// ── IPC ───────────────────────────────────────────────────────────────────────

const send = (msg) => chrome.runtime.sendMessage(msg);

// ── Boot ──────────────────────────────────────────────────────────────────────

async function init() {
  const res = await send({ type: 'GET_STATE' });
  if (res?.ok) {
    state.archive      = res.archivedTabs  || [];
    state.reminders    = res.reminders     || [];
    state.calConnected = res.calConnected  || false;
  }

  bindEvents();
  render();
}

// ── Group rules ───────────────────────────────────────────────────────────────

const GROUP_RULES = [
  { id: 'uni',      label: 'Uni',       icon: '◆', pattern: /canvas|blackboard|coursehero|quizlet|chegg|studocu|ratemyprofessor|\.edu$|ubc|mcgill|utoronto|yorku|sfu|uwaterloo|queensu|western/ },
  { id: 'youtube',  label: 'YouTube',   icon: '◆', pattern: /youtube|youtu\.be/ },
  { id: 'research', label: 'Research',  icon: '◆', pattern: /scholar\.google|jstor|pubmed|researchgate|academia|semanticscholar|arxiv|sciencedirect|springer|ncbi/ },
  { id: 'social',   label: 'Social',    icon: '◆', pattern: /reddit|twitter|x\.com|instagram|facebook|linkedin|tiktok|discord/ },
  { id: 'news',     label: 'News',      icon: '◆', pattern: /cnn|bbc|nytimes|theguardian|globeandmail|cbcnews|washingtonpost|bloomberg|reuters|thestar/ },
  { id: 'code',     label: 'Code',      icon: '◆', pattern: /github|stackoverflow|codepen|replit|codesandbox|w3schools|mdn|developer\.mozilla/ },
  { id: 'docs',     label: 'Docs',      icon: '◆', pattern: /docs\.google|notion|overleaf|confluence|dropbox|onedrive|sharepoint/ },
  { id: 'shopping', label: 'Shopping',  icon: '◆', pattern: /amazon|ebay|etsy|bestbuy|walmart|asos|wayfair|shopify/ },
];

// Partial-match patterns — if title CONTAINS any of these it's junk
const JUNK_TITLE = /service not available|access denied|403 forbidden|404 not found|page not found|not found|gateway timeout|bad gateway|forbidden|unauthorized|just a moment|error \d/i;

// Generic subdomain prefixes that produce meaningless group labels
const GENERIC_SUBDOMAINS = new Set([
  'access','login','auth','sso','portal','secure','account','signin',
  'signup','register','webmail','mail','app','api','www','static','cdn'
]);

function isGroupable(tab) {
  const title = (tab.title || '').trim();
  if (!title || title === tab.domain || title === tab.url) return false;
  if (JUNK_TITLE.test(title)) return false;
  return true;
}

function dedupeByUrl(archive) {
  const seen = new Set();
  return archive.filter(t => {
    if (seen.has(t.url)) return false;
    seen.add(t.url);
    return true;
  });
}

function buildGroups(archive) {
  const deduped  = dedupeByUrl(archive);
  const groups   = [];
  const assigned = new Set();

  // Session groups — tabs archived together in the same batch (e.g. left laptop over weekend)
  const batchMap = {};
  deduped.filter(t => t.batchId).forEach(t => {
    if (!batchMap[t.batchId]) batchMap[t.batchId] = [];
    batchMap[t.batchId].push(t);
  });
  for (const [batchId, tabs] of Object.entries(batchMap)) {
    if (tabs.length >= 3) {
      const date  = new Date(tabs[0].archivedAt);
      const label = date.toLocaleDateString([], { weekday: 'short' }) + ' session';
      groups.push({ id: batchId, label, icon: '◆', tabs, isSession: true });
      tabs.forEach(t => assigned.add(t.id));
    }
  }

  for (const rule of GROUP_RULES) {
    const tabs = deduped.filter(t => !assigned.has(t.id) && isGroupable(t) && rule.pattern.test(t.domain));
    if (tabs.length >= 2) {
      groups.push({ ...rule, tabs });
      tabs.forEach(t => assigned.add(t.id));
    }
  }

  // Auto-group 3+ tabs from the same domain not already categorised
  const domainMap = {};
  deduped.filter(t => !assigned.has(t.id) && isGroupable(t)).forEach(t => {
    if (!domainMap[t.domain]) domainMap[t.domain] = [];
    domainMap[t.domain].push(t);
  });
  for (const [domain, tabs] of Object.entries(domainMap)) {
    if (tabs.length >= 3) {
      const raw = domain.split('.')[0].toLowerCase();
      if (GENERIC_SUBDOMAINS.has(raw)) continue;
      groups.push({ id: `d_${domain}`, label: raw.charAt(0).toUpperCase() + raw.slice(1), icon: '◆', tabs });
    }
  }

  return groups;
}

// ── Render ────────────────────────────────────────────────────────────────────

function render() {
  renderArchiveCount();
  renderGroups();
  renderResults();
  renderReminderBar();
  renderFooter();
}

function renderArchiveCount() {
  const el = document.getElementById('archive-count');
  const n  = state.archive.length;
  el.textContent = n > 0 ? `${n} archived` : '';
}

function renderGroups() {
  const strip  = document.getElementById('groups-strip');
  const groups = buildGroups(state.archive);

  if (!groups.length || state.query) {
    strip.classList.add('hidden');
    return;
  }

  strip.classList.remove('hidden');
  strip.innerHTML = '';

  groups.forEach(group => {
    const wrap = document.createElement('div');
    wrap.className = 'group-chip-wrap';

    const btn = document.createElement('button');
    btn.className = 'group-btn';
    btn.title = `${group.label} · ${group.tabs.length} tabs — hover to preview`;

    const diamond = document.createElement('span');
    diamond.className = 'group-diamond';
    diamond.textContent = '◆';

    const name = document.createElement('span');
    name.className = 'group-name';
    name.textContent = group.label;

    const count = document.createElement('span');
    count.className = 'group-count';
    count.textContent = `${group.tabs.length} tabs`;

    btn.appendChild(diamond);
    btn.appendChild(name);
    btn.appendChild(count);
    wrap.appendChild(btn);

    // Hover panel
    let panel     = null;
    let hideTimer = null;

    const showPanel = () => {
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      if (panel) return;
      panel = buildGroupPanel(group);
      document.body.appendChild(panel);
      const rect = wrap.getBoundingClientRect();
      panel.style.top  = (rect.bottom + 6) + 'px';
      panel.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - 240)) + 'px';
      panel.addEventListener('mouseenter', () => {
        if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      });
      panel.addEventListener('mouseleave', scheduleHide);
    };

    const scheduleHide = () => {
      hideTimer = setTimeout(() => { panel?.remove(); panel = null; }, 120);
    };

    wrap.addEventListener('mouseenter', showPanel);
    wrap.addEventListener('mouseleave', scheduleHide);

    strip.appendChild(wrap);
  });
}

function buildGroupPanel(group) {
  const panel = document.createElement('div');
  panel.className = 'group-panel';

  group.tabs.slice(0, 8).forEach(tab => {
    const item = document.createElement('div');
    item.className = 'group-panel-tab';

    const fav = document.createElement('span');
    fav.className = 'group-panel-fav';
    fav.textContent = (tab.domain || tab.title || '?')[0].toUpperCase();

    const title = document.createElement('span');
    title.className = 'group-panel-title';
    title.textContent = tab.title || tab.domain;

    item.appendChild(fav);
    item.appendChild(title);

    item.addEventListener('click', async () => {
      await send({ type: 'RESTORE_TAB', id: tab.id });
      panel.remove();
    });

    panel.appendChild(item);
  });

  if (group.tabs.length > 1) {
    const restoreAll = document.createElement('button');
    restoreAll.className = 'group-panel-restore-all';
    restoreAll.textContent = group.isSession
      ? `Restore session · ${group.tabs.length} tabs`
      : `Restore all ${group.tabs.length}`;
    restoreAll.addEventListener('click', async () => {
      await send({ type: 'RESTORE_MANY', ids: group.tabs.map(t => t.id) });
      panel.remove();
    });
    panel.appendChild(restoreAll);
  }

  return panel;
}

function renderResults() {
  const wrap = document.getElementById('results-wrap');
  wrap.innerHTML = '';

  const q = state.query.trim().toLowerCase();

  if (!q) {
    renderRecent(wrap);
  } else {
    renderSearch(wrap, q);
  }
}

function renderRecent(wrap) {
  if (!state.archive.length) {
    wrap.appendChild(emptyState(
      'Your vault is empty.',
      'Tabs inactive for 24 hours will appear here automatically.'
    ));
    return;
  }

  const deduped = dedupeByUrl(state.archive);
  const now   = Date.now();
  const DAY   = 24 * 60 * 60 * 1000;
  const today = deduped.filter(t => now - t.archivedAt < DAY);
  const older = deduped.filter(t => now - t.archivedAt >= DAY);

  if (today.length) {
    wrap.appendChild(divider('Archived Today'));
    today.forEach(tab => wrap.appendChild(tabCard(tab)));
  }

  if (older.length) {
    wrap.appendChild(divider('Older'));
    older.slice(0, 30).forEach(tab => wrap.appendChild(tabCard(tab)));
  }
}

function renderSearch(wrap, query) {
  const terms = query.split(/\s+/).filter(Boolean);

  const scored = dedupeByUrl(state.archive)
    .map(tab => {
      const haystack = `${tab.title} ${tab.domain} ${tab.url}`.toLowerCase();
      const score = terms.reduce((acc, t) => {
        if (tab.title.toLowerCase().includes(t)) acc += 3;
        else if (tab.keywords?.includes(t)) acc += 2;
        else if (tab.domain.toLowerCase().includes(t)) acc += 2;
        else if (haystack.includes(t)) acc += 1;
        return acc;
      }, 0);
      return { ...tab, score };
    })
    .filter(t => t.score > 0)
    .sort((a, b) => b.score - a.score);

  if (!scored.length) {
    const el = document.createElement('div');
    el.className = 'no-results';
    el.innerHTML = `<p>Nothing in the vault for <em>"${esc(query)}"</em></p>`;
    wrap.appendChild(el);
    return;
  }

  wrap.appendChild(divider(`${scored.length} result${scored.length !== 1 ? 's' : ''} · "${query}"`));
  scored.forEach(tab => wrap.appendChild(tabCard(tab)));
}

function renderReminderBar() {
  const bar = document.getElementById('reminder-bar');

  const now      = Date.now();
  const upcoming = state.reminders
    .filter(r => !r.fired && r.startTime > now && r.startTime - now < 4 * 60 * 60 * 1000)
    .sort((a, b) => a.startTime - b.startTime)[0];

  if (!upcoming) {
    bar.classList.add('hidden');
    return;
  }

  const minutesUntil = Math.round((upcoming.startTime - now) / 60000);
  const timeStr = minutesUntil < 60
    ? `in ${minutesUntil}m`
    : `in ${Math.round(minutesUntil / 60)}h`;

  document.getElementById('reminder-event').textContent = upcoming.eventTitle;
  document.getElementById('reminder-meta').textContent  = upcoming.tabIds.length
    ? `${upcoming.tabIds.length} tab${upcoming.tabIds.length !== 1 ? 's' : ''} ready · ${timeStr}`
    : timeStr;

  document.getElementById('reminder-restore-btn').onclick = async () => {
    await send({ type: 'RESTORE_MANY', ids: upcoming.tabIds });
  };

  bar.classList.remove('hidden');
}

function renderFooter() {
  const calBtn    = document.getElementById('connect-cal-btn');
  const resyncBtn = document.getElementById('resync-cal-btn');
  if (state.calConnected) {
    calBtn.textContent   = 'Calendar Connected';
    calBtn.disabled      = true;
    calBtn.style.opacity = '0.4';
    calBtn.style.cursor  = 'default';
    resyncBtn.classList.remove('hidden');
  } else {
    calBtn.textContent   = 'Connect Google Calendar';
    calBtn.disabled      = false;
    calBtn.style.opacity = '';
    calBtn.style.cursor  = '';
    resyncBtn.classList.add('hidden');
  }
}

// ── DOM helpers ───────────────────────────────────────────────────────────────

function tabCard(tab) {
  const card = document.createElement('div');
  card.className = 'tab-card';

  // Build favicon element safely (no inline handlers)
  const faviconWrap = document.createElement('div');
  faviconWrap.className = 'favicon-wrap';
  const initial = (tab.domain || tab.title || '?')[0].toUpperCase();
  if (tab.favIconUrl && (tab.favIconUrl.startsWith('http') || tab.favIconUrl.startsWith('data:'))) {
    const img = document.createElement('img');
    img.className = 'favicon-img';
    img.src = tab.favIconUrl;
    img.alt = '';
    img.addEventListener('error', () => {
      const span = document.createElement('span');
      span.className = 'favicon-initial';
      span.textContent = initial;
      img.replaceWith(span);
    });
    faviconWrap.appendChild(img);
  } else {
    const span = document.createElement('span');
    span.className = 'favicon-initial';
    span.textContent = initial;
    faviconWrap.appendChild(span);
  }

  // Build the rest of the card
  const info = document.createElement('div');
  info.className = 'tab-info';
  info.innerHTML = `
    <div class="tab-title" title="${esc(tab.title)}">${esc(tab.title)}</div>
    <div class="tab-meta">
      <span class="tab-domain">${esc(tab.domain)}</span>
      <span class="tab-sep">·</span>
      <span class="tab-age">${timeAgo(tab.archivedAt)}</span>
    </div>
  `;

  const restoreBtn = document.createElement('button');
  restoreBtn.className = 'restore-btn';
  restoreBtn.title = 'Restore this tab';
  restoreBtn.textContent = 'Restore';
  restoreBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    await send({ type: 'RESTORE_TAB', id: tab.id });
  });

  card.appendChild(faviconWrap);
  card.appendChild(info);
  card.appendChild(restoreBtn);

  card.addEventListener('click', async () => {
    await send({ type: 'RESTORE_TAB', id: tab.id });
  });

  return card;
}

function divider(label) {
  const el = document.createElement('div');
  el.className = 'section-divider';
  el.innerHTML = `<span>${esc(label)}</span>`;
  return el;
}

function emptyState(title, sub) {
  const el = document.createElement('div');
  el.className = 'empty-state';
  el.innerHTML = `<p>${title}</p><small>${sub}</small>`;
  return el;
}

// ── Events ────────────────────────────────────────────────────────────────────

function bindEvents() {
  const input    = document.getElementById('search-input');
  const clearBtn = document.getElementById('clear-btn');

  input.addEventListener('input', () => {
    state.query = input.value;
    clearBtn.classList.toggle('hidden', !input.value);
    renderResults();
  });

  clearBtn.addEventListener('click', () => {
    input.value  = '';
    state.query  = '';
    clearBtn.classList.add('hidden');
    input.focus();
    renderResults();
  });

  document.getElementById('connect-cal-btn').addEventListener('click', connectCalendar);
  document.getElementById('archive-now-btn').addEventListener('click', archiveNow);
  document.getElementById('resync-cal-btn').addEventListener('click', resyncCalendar);
}

// ── Archive Now ───────────────────────────────────────────────────────────────

async function archiveNow() {
  const btn = document.getElementById('archive-now-btn');
  btn.textContent = 'Archiving...';
  btn.classList.add('loading');

  const res = await send({ type: 'ARCHIVE_NOW' });

  if (res?.ok) {
    const count = res.count || 0;
    btn.textContent = count > 0 ? `Archived ${count}` : 'Nothing new';
    setTimeout(async () => {
      // Refresh state and re-render
      const state2 = await send({ type: 'GET_STATE' });
      if (state2?.ok) {
        state.archive = state2.archivedTabs || [];
      }
      btn.textContent = 'Archive Now';
      btn.classList.remove('loading');
      render();
    }, 1500);
  } else {
    btn.textContent = 'Archive Now';
    btn.classList.remove('loading');
  }
}

// ── Calendar ──────────────────────────────────────────────────────────────────

async function connectCalendar() {
  const btn = document.getElementById('connect-cal-btn');
  btn.textContent = 'Connecting...';
  btn.disabled = true;

  try {
    const token = await getAuthToken(true);
    if (!token) {
      btn.textContent = 'Connect Google Calendar';
      btn.disabled = false;
      return;
    }

    state.calConnected = true;
    await send({ type: 'SET_CAL_CONNECTED', value: true });

    const res = await send({ type: 'GET_STATE' });
    if (res?.ok) {
      state.reminders    = res.reminders || [];
      state.calConnected = res.calConnected;
    }

    render();
  } catch (err) {
    btn.textContent = 'Connect Google Calendar';
    btn.disabled = false;
    if (!err.message?.toLowerCase().includes('cancel')) {
      console.error('Calendar auth failed:', err);
    }
  }
}


async function resyncCalendar() {
  const btn = document.getElementById('resync-cal-btn');
  btn.textContent = 'Syncing…';
  btn.disabled = true;

  await send({ type: 'RESYNC_CALENDAR' });

  const res = await send({ type: 'GET_STATE' });
  if (res?.ok) state.reminders = res.reminders || [];

  btn.textContent = 'Sync';
  btn.disabled = false;
  render();
}

// ── Utilities ─────────────────────────────────────────────────────────────────

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function timeAgo(ms) {
  const diff = Date.now() - ms;
  const m    = Math.floor(diff / 60000);
  const h    = Math.floor(diff / 3600000);
  const d    = Math.floor(diff / 86400000);
  if (m < 60)  return `${m}m ago`;
  if (h < 24)  return `${h}h ago`;
  if (d === 1) return 'Yesterday';
  if (d < 30)  return `${d}d ago`;
  return new Date(ms).toLocaleDateString([], { month: 'short', day: 'numeric' });
}

// ── Start ─────────────────────────────────────────────────────────────────────
init();
