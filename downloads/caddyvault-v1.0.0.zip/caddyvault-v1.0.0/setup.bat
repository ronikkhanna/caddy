@echo off
REM CaddyVault Extension Setup Script for Windows
REM Run this from the caddyvault directory: setup.bat

echo.
echo ============== Caddy Vault Setup ==============
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python 3 is required. Please install it from python.org
    pause
    exit /b 1
)

echo OK: Python 3 found
echo.

REM Generate icons
echo Generating extension icons...
python create_icons.py
echo.

REM Check if icons were created
if not exist "icons\icon16.png" (
    echo Error: Icon generation failed
    pause
    exit /b 1
)

if not exist "icons\icon48.png" (
    echo Error: Icon generation failed
    pause
    exit /b 1
)

if not exist "icons\icon128.png" (
    echo Error: Icon generation failed
    pause
    exit /b 1
)

echo.
echo ===== Setup complete! =====
echo.
echo Next steps:
echo   1. Open chrome://extensions/ in your Chrome browser
echo   2. Toggle "Developer mode" (top-right corner)
echo   3. Click "Load unpacked"
echo   4. Select the "caddyvault" folder
echo.
echo Your extension is ready!
echo.
echo Optional: Connect Google Calendar
echo   See INSTALL.md for Google Calendar setup instructions
echo.
pause
