#!/bin/bash

# CaddyVault Extension Setup Script
# Run this from the caddyvault directory: bash setup.sh

set -e

echo "🔧 Caddy Vault Setup"
echo "===================="
echo ""

# Check Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Please install it first."
    exit 1
fi

echo "✓ Python 3 found"
echo ""

# Generate icons
echo "📦 Generating extension icons..."
python3 create_icons.py
echo ""

# Check if icons were created
if [ ! -f "icons/icon16.png" ] || [ ! -f "icons/icon48.png" ] || [ ! -f "icons/icon128.png" ]; then
    echo "❌ Icon generation failed"
    exit 1
fi

echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo "  1. Open chrome://extensions/ in your Chrome browser"
echo "  2. Toggle 'Developer mode' (top-right corner)"
echo "  3. Click 'Load unpacked'"
echo "  4. Select the 'caddyvault' folder"
echo ""
echo "🎉 Your extension is ready!"
echo ""
echo "💡 Optional: Connect Google Calendar"
echo "   See INSTALL.md for Google Calendar setup instructions"
echo ""
